#include "sc_signal.h"

int main()
{
	return 0;
}
