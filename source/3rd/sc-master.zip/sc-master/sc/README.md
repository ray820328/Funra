### Sc

- Utility functions

