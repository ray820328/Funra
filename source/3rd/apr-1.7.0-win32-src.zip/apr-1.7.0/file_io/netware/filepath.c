/* NetWare & Win32 have much in common with regards to file names (both are 
 * DOSish) so it makes sense to share some code 
 */
#include "../win32/filepath.c"
