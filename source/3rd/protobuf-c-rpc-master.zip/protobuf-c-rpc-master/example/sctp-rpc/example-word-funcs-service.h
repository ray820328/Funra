#include "example.pb-c.h"

extern Example__WordFuncs_Service example__word_funcs__service__global;

/* extern ProtobufCService *example__word_funcs__service; */
#define example__word_funcs__service \
    ((ProtobufCService *) (&example__word_funcs__service__global))

