
struct _ProtobufC_SCTP_Channel
{
  int fd;
  protobuf_c_boolean is_passive;		/* ie the server */
};


